import Cell from "./cell";


  class Grid {
  constructor(width, height) {
    this.width = width;
    this.height = height;

    this.cells = this._createCells(width, height);
  }
  clicked(cell) {
    cell.clicked();
  }
  rightClicked(cell) {
    cell.rightClicked();
  }
  _createCells(width, height) {
    var i, j, cells = new Array(height);

    for (i = 0; i < height; i++) {
      cells[i] = new Array(width);
      for (j = 0; j < width; j++) {
        cells[i][j] = new Cell(j, i);
      }
    }

    return cells;
  }
  getCell(x, y) {
    if(x < 0 || x >= this.width) {
      return null;
    }
    if(y < 0 || y >= this.height) {
      return null;
    }
    return this.cells[y][x];
  }
  getCells() {
    return [].concat.apply([], this.cells);
  }
  getRandomCell() {
    var x = Math.floor(Math.random() * this.width), y = Math.floor(Math.random() * this.height);

    return this.getCell(x, y);
  }
  walkableNeighbors(cell) {
    var neighbors = [], cells = this.cells, x = cell.x, y = cell.y;

    if (cells[y - 1] && cells[y - 1][x] && !cells[y - 1][x].obstacle) {
      neighbors.push(cells[y - 1][x]);
    }
    if (cells[y + 1] && cells[y + 1][x] && !cells[y + 1][x].obstacle) {
      neighbors.push(cells[y + 1][x]);
    }
    if (cells[y] && cells[y][x - 1] && !cells[y][x - 1].obstacle) {
      neighbors.push(cells[y][x - 1]);
    }
    if (cells[y] && cells[y][x + 1] && !cells[y][x + 1].obstacle) {
      neighbors.push(cells[y][x + 1]);
    }
    return neighbors;
  }
}

export default Grid;
