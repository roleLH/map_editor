
  class Cell {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.dirty = false;
    this.obstacle = false;
    this.player = false;
    this.path = false;
    this.destination = false;
    this.f = 0;
    this.g = 0;
    this.h = 0;
  }
  equals(cell) {
    return (this.x === cell.x && this.y === cell.y);
  }
  isDirty() {
    return this.dirty;
  }
  set(obj) {
    var i, keys = Object.keys(obj), length = keys.length;

    for (i = 0; i < length; i++) {
      this[keys[i]] = obj[keys[i]];
    }

    this.setDirty();
  }
  setClean() {
    this.dirty = false;
  }
  setDirty() {
    this.dirty = true;
  }
  clicked() {
    this.setDirty();
  }
  rightClicked() {
    this.set({
      player: false,
      obstacle: !this.obstacle
    });
  }
  pos() {
    return { x: this.x, y: this.y };
  }
}



  export default Cell;
