



class ActiveTileTool {
  constructor() {

  }


  active() {
    
  }
}